"use strict";
{
    const connect = document.getElementById('connect');
    const notice = document.getElementById('notice');
    connect.addEventListener('click', async () => {
        connect.disabled = true;
        connect.textContent = 'Подключаем…';
        try {
            const current = await browser.windows.getCurrent();
            if (!Number.isInteger(current.id))
                throw new Error('Окно не найдено.');
            await browser.sidebarAction.setPanel({ windowId: current.id, panel: `https://chat.deepseek.com/?askds_window=${current.id}` });
        }
        catch {
            connect.disabled = false;
            connect.textContent = 'Попробовать снова ↗';
            notice.textContent = 'Firefox не разрешил открыть официальный сайт в Sidebar. Проверьте настройки или ограничения сети.';
        }
    });
    const pane = document.getElementById('options');
    const show = (value) => pane.hidden = !value;
    document.getElementById('settings')?.addEventListener('click', () => show(pane.hidden));
    document.getElementById('close')?.addEventListener('click', () => show(false));
    document.addEventListener('keydown', e => { if (e.key === 'Escape')
        show(false); });
    void browser.storage.local.get('settings').then(({ settings }) => {
        for (const input of document.querySelectorAll('[data-setting]')) {
            input.checked = settings?.[input.dataset.setting] !== false;
            input.addEventListener('change', () => {
                void browser.runtime.sendMessage({ type: 'SET_SETTINGS', settings: { [input.dataset.setting]: input.checked } });
            });
        }
    });
}

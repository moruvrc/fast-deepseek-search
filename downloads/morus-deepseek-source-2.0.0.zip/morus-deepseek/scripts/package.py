from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
out=root.parent
with ZipFile(out/'morus-deepseek-firefox-1.5.0.zip','w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((root/'dist').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(root/'dist'))
with ZipFile(out/'morus-deepseek-source-1.5.0.zip','w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or any(part in ('.compiled','dist','node_modules','.git') for part in p.parts):continue
  if p.suffix in ('.zip','.xpi'):continue
  z.write(p,Path('ask-deepseek')/p.relative_to(root))

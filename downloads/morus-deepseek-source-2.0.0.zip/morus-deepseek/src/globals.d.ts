declare const browser: any;
